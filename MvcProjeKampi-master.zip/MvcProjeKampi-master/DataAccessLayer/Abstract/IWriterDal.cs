﻿using EntityLayer.Concrete;

namespace DataAccessLayer.Abstract
{
    public interface IWriterDal:IRepository<Writer>
    {
    }
}
