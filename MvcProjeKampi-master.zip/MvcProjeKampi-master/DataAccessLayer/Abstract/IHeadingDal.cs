﻿using EntityLayer.Concrete;

namespace DataAccessLayer.Abstract
{
    public interface IHeadingDal : IRepository<Heading>
    {
    }
}
