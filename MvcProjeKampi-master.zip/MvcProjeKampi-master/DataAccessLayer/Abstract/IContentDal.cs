﻿using EntityLayer.Concrete;

namespace DataAccessLayer.Abstract
{
    public interface IContentDal : IRepository<Content>
    {
    }
}
