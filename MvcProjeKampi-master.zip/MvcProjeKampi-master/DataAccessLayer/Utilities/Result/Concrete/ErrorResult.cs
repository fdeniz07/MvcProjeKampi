﻿namespace DataAccessLayer.Utilities.Result.Concrete
{
    class ErrorResult : Result
    {
        public ErrorResult(string message) : base(false, message)
        {

        }
        public ErrorResult() : base(false)
        {

        }
    }
}
